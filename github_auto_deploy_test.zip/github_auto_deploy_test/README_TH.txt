ชุดไฟล์ทดสอบ GitHub Auto Deploy

ไฟล์ในชุดนี้ปลอดภัยกว่าเอา index.html / worker.js ตัวจริงไปเปลี่ยน เพราะไม่แก้ logic โปรแกรมหลัก

วิธีใช้:

1) ทดสอบ HTML / Cloudflare Pages
- เข้า GitHub repo: pananth-rental-app
- เข้าโฟลเดอร์ public
- กด Add file > Upload files
- อัปโหลดไฟล์ deploy-test.html
- Commit changes
- รอ Cloudflare Pages Deployments ขึ้น Success
- เปิดลิงก์:
  https://pananth-rental-app.pages.dev/deploy-test.html

2) ทดสอบ Worker / Cloudflare Worker Builds
- เข้า GitHub repo: pananth-rental-app
- เข้าโฟลเดอร์ worker
- กด Add file > Upload files
- อัปโหลดไฟล์ deploy-test.txt
- Commit changes
- กลับไป Cloudflare Worker white-rice-cf72
- ดู Deployments / Build history
- ต้องเห็น build ใหม่ และขึ้น Success

หมายเหตุ:
- ไฟล์ deploy-test.html ไม่ทับ index.html
- ไฟล์ deploy-test.txt ไม่ทับ worker.js
- จึงไม่ควรกระทบระบบห้องเช่าหลัก
